# Republication banlist

This file is part of the [Rollins Nelua Republication License 1.0](LICENSE-NELUA).
It identifies the people excluded from republishing Covered Material under that
license. It does not assert misconduct or change any third-party license.

| Person | Account identifier | Restriction |
| --- | --- | --- |
| Tobias Vetter | `tbsvttr` | No publication, republication, distribution, sublicensing or sale of Covered Material, including modified or compiled copies. |

Policy introduced: 2026-11-18, by the commit first adding this file.

The name and account identifier identify the same listed person. The restriction
also applies when that person uses another account, and to republication directed
by or knowingly performed on behalf of that person. It does not extend to unrelated
people merely because they share a name or later acquire an account identifier.

The list accompanying a particular revision governs that revision. Later edits to
this list apply prospectively and do not withdraw permissions already granted for
earlier revisions. Earlier MIT and other valid license grants remain available;
see LICENSE-NELUA for the precise scope and historical boundary.
